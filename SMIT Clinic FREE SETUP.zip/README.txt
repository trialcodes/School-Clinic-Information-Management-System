extract muna yung naka zip file

Install xampp muna then icheck lahat ng icheck during installation

then after installation punta sa xampp control panel kung then start yung mysql

tapos kung naopen na or nastart na yung xampp punta agad sa nna extract and 

punta ka sa SMIT_folder then double click mo yung set up 


and click install tapos paki antay gang sa magrun yun program or system automatically


then yun pwede na gamitin at default username and password is .. . 


user: admin123
pass: admin 